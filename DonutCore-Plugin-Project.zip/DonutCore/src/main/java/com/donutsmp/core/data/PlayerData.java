package com.donutsmp.core.data;

import org.bukkit.Location;
import java.util.*;

public class PlayerData {
    private final UUID uuid;
    private double balance;
    private long shards;
    private double bounty;
    private double sellMultiplier;
    private final Map<String, Location> homes = new HashMap<>();
    private String teamName;
    private final List<String> sellHistory = new ArrayList<>();

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.balance = 1000.0; // Starting balance
        this.shards = 0;
        this.bounty = 0.0;
        this.sellMultiplier = 1.0;
        this.teamName = null;
    }

    public UUID getUuid() { return uuid; }
    
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = Math.max(0, balance); }
    public void addBalance(double amount) { this.balance += amount; }
    public boolean removeBalance(double amount) {
        if (this.balance >= amount) {
            this.balance -= amount;
            return true;
        }
        return false;
    }

    public long getShards() { return shards; }
    public void addShards(long amount) { this.shards += amount; }
    public boolean removeShards(long amount) {
        if (this.shards >= amount) {
            this.shards -= amount;
            return true;
        }
        return false;
    }

    public double getBounty() { return bounty; }
    public void addBounty(double amount) { this.bounty += amount; }
    public void resetBounty() { this.bounty = 0.0; }

    public double getSellMultiplier() { return sellMultiplier; }
    public void setSellMultiplier(double sellMultiplier) { this.sellMultiplier = sellMultiplier; }

    public Map<String, Location> getHomes() { return homes; }
    public void setHome(String name, Location loc) { homes.put(name.toLowerCase(), loc); }
    public Location getHome(String name) { return homes.get(name.toLowerCase()); }

    public String getTeamName() { return teamName; }
    public void setTeamName(String teamName) { this.teamName = teamName; }

    public List<String> getSellHistory() { return sellHistory; }
    public void addSellHistory(String entry) {
        sellHistory.add(0, entry);
        if (sellHistory.size() > 50) {
            sellHistory.remove(sellHistory.size() - 1);
        }
    }
}
