package com.donutsmp.core.commands;

import com.donutsmp.core.DonutCore;
import com.donutsmp.core.data.PlayerData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class CoreCommands implements CommandExecutor {
    private final DonutCore plugin;

    public CoreCommands(DonutCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("คำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น!", NamedTextColor.RED));
            return true;
        }

        PlayerData data = plugin.getProfileManager().getProfile(player.getUniqueId());

        switch (cmd.getName().toLowerCase()) {
            case "bal" -> handleBalance(player, data, args);
            case "baltop" -> handleBalTop(player, args);
            case "pay" -> handlePay(player, data, args);
            case "shards" -> handleShards(player, data, args);
            case "bounty" -> handleBounty(player, data, args);
            case "sell" -> handleSell(player, data);
            case "sellhistory" -> handleSellHistory(player, data);
            case "sellmulti" -> player.sendMessage(Component.text("Sell Multiplier ปัจจุบันของคุณ: x" + data.getSellMultiplier(), NamedTextColor.GOLD));
            case "worth" -> handleWorth(player, args);
            case "ah" -> handleAuctionHouse(player, args);
            case "orders", "order" -> handleOrders(player, args);
            case "sethome" -> handleSetHome(player, data, args);
            case "home" -> handleHome(player, data, args);
            case "spawn" -> handleSpawn(player);
            case "rtp" -> handleRtp(player);
            case "tpa" -> handleTpa(player, args);
            case "tpaccept" -> handleTpAccept(player);
            case "team" -> handleTeam(player, data, args);
            case "leaderboard" -> handleLeaderboard(player, args);
        }
        return true;
    }

    private void handleBalance(Player player, PlayerData data, String[] args) {
        if (args.length == 0) {
            player.sendMessage(Component.text("ยอดเงินคงเหลือ: $" + String.format("%,.2f", data.getBalance()), NamedTextColor.GOLD));
        } else {
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                player.sendMessage(Component.text("ไม่พบผู้เล่นดังกล่าว", NamedTextColor.RED));
                return;
            }
            PlayerData targetData = plugin.getProfileManager().getProfile(target.getUniqueId());
            player.sendMessage(Component.text("ยอดเงินของ " + target.getName() + ": $" + String.format("%,.2f", targetData.getBalance()), NamedTextColor.GOLD));
        }
    }

    private void handleBalTop(Player player, String[] args) {
        int page = 1;
        if (args.length > 0) {
            try { page = Math.max(1, Integer.parseInt(args[0])); } catch (NumberFormatException ignored) {}
        }
        player.sendMessage(Component.text("--- อันดับคนรวยที่สุด Baltop (หน้า " + page + ") ---", NamedTextColor.YELLOW));
        List<Map.Entry<UUID, Double>> top = plugin.getProfileManager().getTopBalances(10);
        int rank = 1;
        for (var entry : top) {
            String name = Bukkit.getOfflinePlayer(entry.getKey()).getName();
            player.sendMessage(Component.text("#" + rank + " " + (name != null ? name : "Unknown") + " §8- §a$" + String.format("%,.2f", entry.getValue())));
            rank++;
        }
    }

    private void handlePay(Player player, PlayerData data, String[] args) {
        if (args.length < 2) {
            player.sendMessage(Component.text("การใช้งาน: /pay <player> <amount>", NamedTextColor.RED));
            return;
        }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || target.equals(player)) {
            player.sendMessage(Component.text("ผู้เล่นไม่ถูกต้อง", NamedTextColor.RED));
            return;
        }
        try {
            double amount = Double.parseDouble(args[1]);
            if (amount <= 0 || !data.removeBalance(amount)) {
                player.sendMessage(Component.text("ยอดเงินไม่พอ หรือจำนวนเงินไม่ถูกต้อง", NamedTextColor.RED));
                return;
            }
            plugin.getProfileManager().getProfile(target.getUniqueId()).addBalance(amount);
            player.sendMessage(Component.text("โอนเงินจำนวน $" + String.format("%,.2f", amount) + " ให้แก่ " + target.getName() + " สำเร็จ!", NamedTextColor.GREEN));
            target.sendMessage(Component.text("คุณได้รับเงิน $" + String.format("%,.2f", amount) + " จาก " + player.getName(), NamedTextColor.GREEN));
        } catch (NumberFormatException e) {
            player.sendMessage(Component.text("กรุณาระบุจำนวนเงินเป็นตัวเลข", NamedTextColor.RED));
        }
    }

    private void handleShards(Player player, PlayerData data, String[] args) {
        if (args.length == 0) {
            player.sendMessage(Component.text("Shards ของคุณ: " + String.format("%,d", data.getShards()) + " Shards", NamedTextColor.LIGHT_PURPLE));
        } else {
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                player.sendMessage(Component.text("ไม่พบผู้เล่นดังกล่าว", NamedTextColor.RED));
                return;
            }
            PlayerData targetData = plugin.getProfileManager().getProfile(target.getUniqueId());
            player.sendMessage(Component.text("Shards ของ " + target.getName() + ": " + String.format("%,d", targetData.getShards()), NamedTextColor.LIGHT_PURPLE));
        }
    }

    private void handleBounty(Player player, PlayerData data, String[] args) {
        if (args.length >= 3 && args[0].equalsIgnoreCase("add")) {
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null || target.equals(player)) {
                player.sendMessage(Component.text("ไม่พบผู้เล่นหรือผู้เล่นไม่ถูกต้อง", NamedTextColor.RED));
                return;
            }
            try {
                double amount = Double.parseDouble(args[2]);
                if (amount <= 0 || !data.removeBalance(amount)) {
                    player.sendMessage(Component.text("ยอดเงินไม่พอสำหรับการตั้งค่าหัว", NamedTextColor.RED));
                    return;
                }
                plugin.getProfileManager().getProfile(target.getUniqueId()).addBounty(amount);
                Bukkit.broadcast(Component.text("§c[Bounty] §e" + player.getName() + " §7ได้ตั้งค่าหัว §c" + target.getName() + " §7เป็นจำนวน §a$" + String.format("%,.2f", amount)));
            } catch (NumberFormatException e) {
                player.sendMessage(Component.text("กรุณาระบุจำนวนเงินเป็นตัวเลข", NamedTextColor.RED));
            }
        } else {
            player.sendMessage(Component.text("--- กระดานค่าหัว DonutSMP ---", NamedTextColor.RED));
            List<Map.Entry<UUID, Double>> bounties = plugin.getProfileManager().getTopBounties(5);
            if (bounties.isEmpty()) {
                player.sendMessage(Component.text("ขณะนี้ยังไม่มีผู้เล่นที่มีค่าหัว", NamedTextColor.GRAY));
            } else {
                for (var b : bounties) {
                    String name = Bukkit.getOfflinePlayer(b.getKey()).getName();
                    player.sendMessage(Component.text("☠ " + (name != null ? name : "Unknown") + " §8- §c$" + String.format("%,.2f", b.getValue())));
                }
            }
        }
    }

    private void handleSell(Player player, PlayerData data) {
        var item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            player.sendMessage(Component.text("กรุณาถือไอเทมในมือที่ต้องการขาย", NamedTextColor.RED));
            return;
        }
        double basePrice = getItemPrice(item.getType());
        if (basePrice <= 0) {
            player.sendMessage(Component.text("ไอเทมนี้ไม่สามารถขายได้", NamedTextColor.RED));
            return;
        }
        int amount = item.getAmount();
        double total = basePrice * amount * data.getSellMultiplier();
        player.getInventory().setItemInMainHand(null);
        data.addBalance(total);
        data.addSellHistory("ขาย " + item.getType().name() + " x" + amount + " เป็นเงิน $" + String.format("%,.2f", total));
        player.sendMessage(Component.text("ขาย " + item.getType().name() + " x" + amount + " ได้รับเงิน §a$" + String.format("%,.2f", total) + " §7(Multi: x" + data.getSellMultiplier() + ")", NamedTextColor.GREEN));
    }

    private void handleSellHistory(Player player, PlayerData data) {
        player.sendMessage(Component.text("--- ประวัติการขายไอเทมล่าสุด ---", NamedTextColor.YELLOW));
        var history = data.getSellHistory();
        if (history.isEmpty()) {
            player.sendMessage(Component.text("ยังไม่มีประวัติการขาย", NamedTextColor.GRAY));
            return;
        }
        for (int i = 0; i < Math.min(5, history.size()); i++) {
            player.sendMessage(Component.text("• " + history.get(i), NamedTextColor.GRAY));
        }
    }

    private void handleWorth(Player player, String[] args) {
        Material mat = (args.length > 0) ? Material.matchMaterial(args[0]) : player.getInventory().getItemInMainHand().getType();
        if (mat == null || mat.isAir()) {
            player.sendMessage(Component.text("ไม่พบไอเทมที่ต้องการตรวจสอบ", NamedTextColor.RED));
            return;
        }
        double price = getItemPrice(mat);
        player.sendMessage(Component.text("ราคาพื้นฐานของ " + mat.name() + ": §a$" + String.format("%,.2f", price) + " / ชิ้น", NamedTextColor.YELLOW));
    }

    private double getItemPrice(Material mat) {
        return switch (mat) {
            case DIAMOND -> 150.0;
            case EMERALD -> 100.0;
            case GOLD_INGOT -> 50.0;
            case IRON_INGOT -> 25.0;
            case NETHERITE_INGOT -> 1000.0;
            case COAL -> 10.0;
            case WHEAT -> 5.0;
            default -> 2.0;
        };
    }

    private void handleAuctionHouse(Player player, String[] args) {
        if (args.length >= 2 && args[0].equalsIgnoreCase("sell")) {
            try {
                double price = Double.parseDouble(args[1]);
                if (player.getInventory().getItemInMainHand().getType().isAir()) {
                    player.sendMessage(Component.text("กรุณาถือไอเทมที่ต้องการลงขาย", NamedTextColor.RED));
                    return;
                }
                player.sendMessage(Component.text("ลงขายใน Auction House ราคา $" + String.format("%,.2f", price) + " สำเร็จ!", NamedTextColor.GREEN));
            } catch (NumberFormatException e) {
                player.sendMessage(Component.text("กรุณาระบุราคาเป็นตัวเลข", NamedTextColor.RED));
            }
        } else {
            String filter = (args.length > 0) ? args[0] : "ทั้งหมด";
            player.sendMessage(Component.text("กำลังเปิด Auction House GUI (ค้นหา: " + filter + ")...", NamedTextColor.GOLD));
        }
    }

    private void handleOrders(Player player, String[] args) {
        String query = (args.length > 0) ? args[0] : "ทั้งหมด";
        player.sendMessage(Component.text("เปิดเมนู Custom Orders / Buy Orders [ค้นหา: " + query + "]...", NamedTextColor.AQUA));
    }

    private void handleSetHome(Player player, PlayerData data, String[] args) {
        String homeName = (args.length > 0) ? args[0] : "home";
        data.setHome(homeName, player.getLocation());
        player.sendMessage(Component.text("ตั้งจุด Home '" + homeName + "' เรียบร้อยแล้ว!", NamedTextColor.GREEN));
    }

    private void handleHome(Player player, PlayerData data, String[] args) {
        String homeName = (args.length > 0) ? args[0] : "home";
        Location loc = data.getHome(homeName);
        if (loc == null) {
            player.sendMessage(Component.text("ไม่พบจุด Home: " + homeName, NamedTextColor.RED));
            return;
        }
        player.teleport(loc);
        player.sendMessage(Component.text("วาร์ปไปยัง Home '" + homeName + "' สำเร็จ!", NamedTextColor.GREEN));
    }

    private void handleSpawn(Player player) {
        Location spawn = plugin.getProfileManager().getSpawnLocation();
        if (spawn == null) {
            spawn = player.getWorld().getSpawnLocation();
        }
        player.teleport(spawn);
        player.sendMessage(Component.text("วาร์ปไปยัง Spawn สำเร็จ!", NamedTextColor.GREEN));
    }

    private void handleRtp(Player player) {
        int x = ThreadLocalRandom.current().nextInt(-2500, 2500);
        int z = ThreadLocalRandom.current().nextInt(-2500, 2500);
        int y = player.getWorld().getHighestBlockYAt(x, z) + 1;
        Location rtpLoc = new Location(player.getWorld(), x + 0.5, y, z + 0.5);
        player.teleport(rtpLoc);
        player.sendMessage(Component.text("วาร์ปแบบสุ่มไปยังพิกัด X: " + x + ", Z: " + z, NamedTextColor.LIGHT_PURPLE));
    }

    private void handleTpa(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(Component.text("การใช้งาน: /tpa <player>", NamedTextColor.RED));
            return;
        }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || target.equals(player)) {
            player.sendMessage(Component.text("ไม่พบผู้เล่นหรือไม่สามารถส่งให้ตัวเองได้", NamedTextColor.RED));
            return;
        }
        plugin.getProfileManager().sendTpa(player.getUniqueId(), target.getUniqueId());
        player.sendMessage(Component.text("ส่งคำขอ TPA ไปยัง " + target.getName() + " แล้ว", NamedTextColor.YELLOW));
        target.sendMessage(Component.text(player.getName() + " ได้ส่งคำขอเทเลพอร์ตมาหาคุณ พิมพ์ /tpaccept เพื่อยอมรับ", NamedTextColor.GOLD));
    }

    private void handleTpAccept(Player player) {
        UUID requesterUuid = plugin.getProfileManager().getTpaRequester(player.getUniqueId());
        if (requesterUuid == null) {
            player.sendMessage(Component.text("ไม่มีคำขอ TPA ค้างอยู่", NamedTextColor.RED));
            return;
        }
        Player requester = Bukkit.getPlayer(requesterUuid);
        if (requester != null && requester.isOnline()) {
            requester.teleport(player.getLocation());
            requester.sendMessage(Component.text("เทเลพอร์ตไปยัง " + player.getName() + " สำเร็จ!", NamedTextColor.GREEN));
            player.sendMessage(Component.text("ยอมรับคำขอเทเลพอร์ตแล้ว", NamedTextColor.GREEN));
        } else {
            player.sendMessage(Component.text("ผู้เล่นคนดังกล่าวไม่ได้ออนไลน์แล้ว", NamedTextColor.RED));
        }
        plugin.getProfileManager().removeTpa(player.getUniqueId());
    }

    private void handleTeam(Player player, PlayerData data, String[] args) {
        if (args.length == 0) {
            player.sendMessage(Component.text("คำสั่งทีม: /team create <name>, /team join <name>, /team leave, /team info", NamedTextColor.AQUA));
            return;
        }
        if (args[0].equalsIgnoreCase("create") && args.length > 1) {
            data.setTeamName(args[1]);
            player.sendMessage(Component.text("สร้างทีม " + args[1] + " เรียบร้อยแล้ว!", NamedTextColor.GREEN));
        } else if (args[0].equalsIgnoreCase("info")) {
            String team = data.getTeamName();
            player.sendMessage(Component.text("ทีมของคุณ: " + (team != null ? team : "ยังไม่มีทีม"), NamedTextColor.GOLD));
        } else if (args[0].equalsIgnoreCase("leave")) {
            data.setTeamName(null);
            player.sendMessage(Component.text("ออกจากทีมแล้ว", NamedTextColor.YELLOW));
        }
    }

    private void handleLeaderboard(Player player, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("bal")) {
            handleBalTop(player, new String[0]);
        } else {
            player.sendMessage(Component.text("คำสั่ง Leaderboard: /leaderboard bal", NamedTextColor.YELLOW));
        }
    }
}
