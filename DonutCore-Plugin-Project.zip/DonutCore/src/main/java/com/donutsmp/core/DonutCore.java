package com.donutsmp.core;

import com.donutsmp.core.commands.CoreCommands;
import com.donutsmp.core.listeners.BountyListener;
import com.donutsmp.core.managers.ProfileManager;
import org.bukkit.plugin.java.JavaPlugin;

public class DonutCore extends JavaPlugin {
    private static DonutCore instance;
    private ProfileManager profileManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.profileManager = new ProfileManager();

        CoreCommands cmdExecutor = new CoreCommands(this);
        String[] commands = {
                "bal", "baltop", "pay", "bounty", "sell", "sellhistory",
                "sellmulti", "worth", "ah", "order", "orders", "shards",
                "sethome", "home", "spawn", "rtp", "tpa", "tpaccept",
                "team", "leaderboard"
        };

        for (String cmd : commands) {
            if (getCommand(cmd) != null) {
                getCommand(cmd).setExecutor(cmdExecutor);
            }
        }

        getServer().getPluginManager().registerEvents(new BountyListener(this), this);

        getLogger().info("=======================================");
        getLogger().info(" DonutCore (DonutSMP Plugin Suite)");
        getLogger().info(" เปิดใช้งานสำเร็จ รองรับระบบทุกคำสั่งแล้ว!");
        getLogger().info("=======================================");
    }

    @Override
    public void onDisable() {
        getLogger().info("DonutCore ปิดระบบเรียบร้อยแล้ว!");
    }

    public static DonutCore getInstance() { return instance; }
    public ProfileManager getProfileManager() { return profileManager; }
}
