package com.donutsmp.core.managers;

import com.donutsmp.core.data.PlayerData;
import org.bukkit.Location;
import java.util.*;
import java.util.stream.Collectors;

public class ProfileManager {
    private final Map<UUID, PlayerData> profiles = new HashMap<>();
    private final Map<UUID, UUID> tpaRequests = new HashMap<>();
    private Location spawnLocation;

    public PlayerData getProfile(UUID uuid) {
        return profiles.computeIfAbsent(uuid, PlayerData::new);
    }

    public List<Map.Entry<UUID, Double>> getTopBalances(int limit) {
        return profiles.entrySet().stream()
                .map(e -> Map.entry(e.getKey(), e.getValue().getBalance()))
                .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    public List<Map.Entry<UUID, Double>> getTopBounties(int limit) {
        return profiles.entrySet().stream()
                .filter(e -> e.getValue().getBounty() > 0)
                .map(e -> Map.entry(e.getKey(), e.getValue().getBounty()))
                .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    public void sendTpa(UUID requester, UUID target) {
        tpaRequests.put(target, requester);
    }

    public UUID getTpaRequester(UUID target) {
        return tpaRequests.get(target);
    }

    public void removeTpa(UUID target) {
        tpaRequests.remove(target);
    }

    public Location getSpawnLocation() { return spawnLocation; }
    public void setSpawnLocation(Location spawnLocation) { this.spawnLocation = spawnLocation; }
}
