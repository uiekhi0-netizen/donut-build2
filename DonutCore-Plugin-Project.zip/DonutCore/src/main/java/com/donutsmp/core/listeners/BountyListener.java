package com.donutsmp.core.listeners;

import com.donutsmp.core.DonutCore;
import com.donutsmp.core.data.PlayerData;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class BountyListener implements Listener {
    private final DonutCore plugin;

    public BountyListener(DonutCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;

        PlayerData victimData = plugin.getProfileManager().getProfile(victim.getUniqueId());
        double bounty = victimData.getBounty();

        if (bounty > 0) {
            PlayerData killerData = plugin.getProfileManager().getProfile(killer.getUniqueId());
            killerData.addBalance(bounty);
            victimData.resetBounty();
            Bukkit.broadcast(Component.text("§c[Bounty] §a" + killer.getName() + " §7ได้สังหาร §c" + victim.getName() + " §7และได้รับเงินค่าหัว §a$" + String.format("%,.2f", bounty) + "§7!"));
        }
    }
}
