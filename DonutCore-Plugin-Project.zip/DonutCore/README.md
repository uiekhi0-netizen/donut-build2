# DonutCore - DonutSMP Complete Plugin Suite

ระบบปลั๊กอินสไตล์ **DonutSMP** ครบวงจร พัฒนาสำหรับ Minecraft Paper / Spigot 1.20+ (Java 17+)

## รายการคำสั่งที่ติดตั้งในระบบ:
- `/bal [player]` - ตรวจสอบยอดเงิน
- `/baltop [page]` - อันดับผู้เล่นที่รวยที่สุด
- `/pay <player> <amount>` - โอนเงินให้ผู้เล่น
- `/bounty [player]` - ดูกระดานค่าหัว
- `/bounty add <player> <amount>` - เพิ่มเงินค่าหัวผู้เล่น
- `/sell` - ขายไอเทมในมือ พร้อมคิดตัวคูณ Sell Multiplier
- `/sellhistory` - ดูประวัติการขายย้อนหลัง
- `/sellmulti` - ดูตัวคูณราคาขายปัจจุบัน
- `/worth [item]` - ตรวจสอบราคาพื้นฐานของไอเทม
- `/ah [search]` / `/ah sell <price>` - ตลาดประมูล Auction House
- `/order <search>` / `/orders` - ระบบ Buy Orders
- `/shards [player]` - ดูจำนวน Shards พิเศษ
- `/sethome [name]`, `/home [name]` - จุดวาร์ปบ้านส่วนตัว
- `/spawn` - เทเลพอร์ตไปจุดเกิดเซิร์ฟเวอร์
- `/rtp` - สุ่มวาร์ปสำรวจโลก
- `/tpa <player>`, `/tpaccept` - คำขอเทเลพอร์ตหาผู้เล่น
- `/team` - ระบบสร้างและจัดการทีม
- `/leaderboard bal` - ดูตารางอันดับเศรษฐกิจ

## วิธีการ Compile:
รันคำสั่ง Maven ในโฟลเดอร์โปรเจกต์:
```bash
mvn clean package
```
ไฟล์ `.jar` จะถูกสร้างขึ้นในโฟลเดอร์ `target/` เพื่อนำไปใส่ในโฟลเดอร์ `plugins/` ของเซิร์ฟเวอร์ได้ทันที
